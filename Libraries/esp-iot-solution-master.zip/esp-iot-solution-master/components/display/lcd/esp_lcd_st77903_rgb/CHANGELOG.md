# ChangeLog

## v0.0.1 - 2023-1-30

### Enhancements:

* Implement the driver for the ST77903 LCD controller
* Support RGB interface


