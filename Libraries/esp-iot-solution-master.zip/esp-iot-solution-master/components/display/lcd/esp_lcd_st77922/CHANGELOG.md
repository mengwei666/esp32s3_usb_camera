# ChangeLog

## v0.0.3 - 2024-3-27

### Enhancements:

### bugfix

* Fix the logic when checking conflicting commands between initialization sequence and driver
* Fix the wrong command structure in the README.md

## v0.0.2 - 2024-2-19

### Enhancements:

* Add notes of X coordinate limitation in README.md

## v0.0.1 - 2024-1-22

### Enhancements:

* Implement the driver for the ST77922 LCD controller
* Support SPI and QSPI interface
