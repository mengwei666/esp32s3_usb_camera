# ChangeLog

## v0.0.1 - 2023-12-01

### Enhancements:

* Implement the driver for the NV3022B LCD controller
* Support SPI interface
