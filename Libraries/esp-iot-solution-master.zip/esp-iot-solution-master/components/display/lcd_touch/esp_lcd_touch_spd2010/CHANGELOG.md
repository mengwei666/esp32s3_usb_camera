# ChangeLog

## v0.0.1 - 2023-08-21

### Enhancements:

* Implement the driver for the SPD2010 Touch controller
* Support read point on polling
* Support read point on interrupt callback
