# ChangeLog

## v0.0.1 - 2024-02-19

### Enhancements:

* Implement the driver for the ST7123 Touch controller
