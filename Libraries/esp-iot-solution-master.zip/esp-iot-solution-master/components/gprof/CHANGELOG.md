# ChangeLog

## v0.1.0 - 2023-05-18

* Add basic GProf component
