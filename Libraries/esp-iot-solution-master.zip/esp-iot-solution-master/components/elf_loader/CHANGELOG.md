# ChangeLog

## v0.1.0 - 2023-08-14

* Add basic ELF loader component
