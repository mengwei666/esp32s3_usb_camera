# ChangeLog

## v1.1.1 - 2023-03-20

### Bug Fixes:

* Disable gptimer in function pwm_audio_stop and pwm_audio_deinit.

## v1.1.0 - 2023-02-20

### Enhancements:
* Support idf release/5.0
* Remove esp32xx_timer_group_struct.h

## v1.1.0 - 2022-06-21
### Enhancements:
* First submit
* Support idf release/4.4