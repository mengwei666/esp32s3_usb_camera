## v0.1.0

This is the first release version for BLE services component in Espressif Component Registry, more detailed descriptions about the project, please refer to [User_Guide](https://docs.espressif.com/projects/espressif-esp-iot-solution/en/latest/bluetooth/ble_services.html).

Features:
- ANS: Support Alert Notification Service
- BAS: Support Battery Service
- DIS: Support Device Information Service
- HRS: Support Heart Rate Service
- HTS: Support Health Thermometer Service
- TPS: Support TX Power Service
