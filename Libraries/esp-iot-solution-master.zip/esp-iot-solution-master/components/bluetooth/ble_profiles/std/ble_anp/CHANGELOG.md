## v0.1.0

This is the first release version for Alert Notification Profile component in Espressif Component Registry, more detailed descriptions about the project, please refer to [User_Guide](https://docs.espressif.com/projects/espressif-esp-iot-solution/en/latest/bluetooth/ble_profiles.html).

Features:
- ANP: Support Alert Notification Profile.
