# Component: Light

## NOTE:

This component has been deprecated, please switch to [lightbulb_driver](../lightbulb_driver/README.md) component.
