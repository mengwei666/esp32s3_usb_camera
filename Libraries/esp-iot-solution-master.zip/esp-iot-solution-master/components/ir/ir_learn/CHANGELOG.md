# ChangeLog

## v0.2.0 - 2024-01-26

* Optimize the structure definition

## v0.1.1 - 2023-11-23

* Fix possible cmake_utilities dependency issue

## v0.1.0 - 2023-1-5

### Enhancements:

* Initial version
